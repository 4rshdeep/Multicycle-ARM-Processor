#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.4"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto 02b29d9d0bcd415ab0689b9a8ddee8b0 -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L secureip --snapshot shifter_behav xil_defaultlib.shifter -log elaborate.log
